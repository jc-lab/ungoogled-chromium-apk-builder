This directory contains third-party libraries used by devutils.

Contents:

* [python-unidiff](//github.com/matiasb/python-unidiff)
    * For parsing and modifying unified diffs.
